class Notifications{
  String day;
  String time;
  String name;
  String address;

  Notifications({this.day,this.time,this.name,this.address});
}