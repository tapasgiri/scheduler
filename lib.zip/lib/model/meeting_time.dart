class MeetingTime{
  String time;
  String day;

  MeetingTime({this.time,this.day});
}