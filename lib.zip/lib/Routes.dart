class Routes{
  /*static const String contacts = ContactsPage.routeName;
  static const String events = EventsPage.routeName;
  static const String notes = NotesPage.routeName;*/
}